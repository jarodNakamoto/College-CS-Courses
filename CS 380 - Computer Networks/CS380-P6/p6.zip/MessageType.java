public enum MessageType {

    CONNECT, COMMAND, BOARD, MOVE, ERROR;

    private static final long serialVersionUID = 0L;
}
